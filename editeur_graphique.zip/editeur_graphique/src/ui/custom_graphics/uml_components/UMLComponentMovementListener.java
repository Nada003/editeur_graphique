package ui.custom_graphics.uml_components;

public interface UMLComponentMovementListener {
    void  componentMoved(UMLComponent c);
}
