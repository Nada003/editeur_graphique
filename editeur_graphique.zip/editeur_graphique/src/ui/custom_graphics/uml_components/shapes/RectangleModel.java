package ui.custom_graphics.uml_components.shapes;

import ui.custom_graphics.uml_components.UMLModel;

public class RectangleModel implements UMLModel {
    public String label;

    public RectangleModel(String label) {
        this.label = label;
    }
}
