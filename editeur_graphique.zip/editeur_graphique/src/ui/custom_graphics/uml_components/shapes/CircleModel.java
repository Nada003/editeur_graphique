package ui.custom_graphics.uml_components.shapes;

import ui.custom_graphics.uml_components.UMLModel;

public class CircleModel implements UMLModel {
    public String label;

    public CircleModel(String label) {
        this.label = label;
    }
}
