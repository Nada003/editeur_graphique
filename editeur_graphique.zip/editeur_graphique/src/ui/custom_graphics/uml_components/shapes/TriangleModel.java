package ui.custom_graphics.uml_components.shapes;

import ui.custom_graphics.uml_components.UMLModel;

public class TriangleModel implements UMLModel {
    public String label;

    public TriangleModel(String label) {
        this.label = label;
    }
}
