package ui.custom_graphics.uml_components.connect_components.aggregations;

import ui.custom_graphics.uml_components.UMLModel;

public class AggregationModel implements UMLModel {
    public String diamond;

    public AggregationModel(String diamond) {
        this.diamond = diamond;
    }
}
