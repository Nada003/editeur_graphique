/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ui.custom_graphics.uml_components.connect_components.realization;

import ui.custom_graphics.uml_components.UMLModel;

public class RealizationModel implements UMLModel {
    public String dashedArrow;

    public RealizationModel(String dashedArrow) {
        this.dashedArrow = dashedArrow;
    }
}
