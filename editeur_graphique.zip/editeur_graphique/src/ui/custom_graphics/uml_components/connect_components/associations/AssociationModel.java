package ui.custom_graphics.uml_components.connect_components.associations;

import ui.custom_graphics.uml_components.UMLModel;

public class AssociationModel implements UMLModel {

    public String line;
    public AssociationModel(String line) {

        this.line = line;
    }
}
