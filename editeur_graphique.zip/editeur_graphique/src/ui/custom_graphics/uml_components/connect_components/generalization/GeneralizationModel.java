package ui.custom_graphics.uml_components.connect_components.generalization;

import ui.custom_graphics.uml_components.UMLModel;

public class GeneralizationModel implements UMLModel {

    public String arrow;
    public GeneralizationModel(String arrow) {
        this.arrow = arrow;
    }
}
