package ui.custom_graphics.uml_components.connect_components;

public interface RolationPointMovedListner {
    void doAction();
}
