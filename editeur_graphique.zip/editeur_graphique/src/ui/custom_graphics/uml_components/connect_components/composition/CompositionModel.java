package ui.custom_graphics.uml_components.connect_components.composition;

import ui.custom_graphics.uml_components.UMLModel;

public class CompositionModel implements UMLModel {
    public String filledDiamond;

    public CompositionModel(String filledDiamond) {
        this.filledDiamond = filledDiamond;
    }
}