

package ui.custom_graphics.uml_components.connect_components.dependency;

import ui.custom_graphics.uml_components.UMLModel;

public class DependencyModel implements UMLModel {
    public String dashedArrow;

    public DependencyModel(String dashedArrow) {
        this.dashedArrow = dashedArrow;
    }
}
