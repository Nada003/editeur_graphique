package ui.custom_graphics.uml_components;

import java.io.Serializable;

public interface UMLModel extends Serializable {
}
