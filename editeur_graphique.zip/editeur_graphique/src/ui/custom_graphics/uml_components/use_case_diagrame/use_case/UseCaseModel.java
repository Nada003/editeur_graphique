package ui.custom_graphics.uml_components.use_case_diagrame.use_case;

import ui.custom_graphics.uml_components.UMLModel;

public class UseCaseModel implements UMLModel {
   public  String scenario;

    public UseCaseModel(String scenario) {

        this.scenario = scenario;
    }
}
