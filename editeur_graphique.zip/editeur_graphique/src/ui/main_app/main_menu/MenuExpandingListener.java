package ui.main_app.main_menu;

public interface MenuExpandingListener {
    void doAction();
}
