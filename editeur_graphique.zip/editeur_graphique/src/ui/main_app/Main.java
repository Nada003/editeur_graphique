package ui.main_app;

public class Main {
    public static void main(String[] args) {
       var app =  new Application();
    }
}